TODO: list team members, document who did what, discuss
anything interesting about your implementation.

I worked with Tayseer Karrossi. We both worked on all the functions separately and discussed our results. I was a 
bit confused in particular on how to implement the to_hex() function and Tayseer explained the functionalities
of the required libraries and also implemented his version of it. I helped debug his version. It was a collaborative
effort. I also added some unit tests for some of the simpler functions like the unary minus operator. 
